﻿namespace Ambev.DeveloperEvaluation.WebApi.Responses
{
    public class GeolocationResponse
    {
        public string Lat { get; set; } = string.Empty;
        public string Long { get; set; } = string.Empty;
    }
}
